�й�usart��dma����Э�鿪��
https://blog.csdn.net/songskygo/article/details/89568679
https://blog.csdn.net/Naisu_kun/article/details/112478419
https://blog.csdn.net/weixin_42067548/article/details/105099049
https://blog.csdn.net/qq_36482723/article/details/113710276
https://www.21ic.com/article/875523.html

	MX_DMA_Init();
  MX_USART1_UART_Init();
  https://zhidao.baidu.com/question/987016987170580899.html
  
  
  
  iic
  https://blog.csdn.net/walleva96/article/details/115920783
  https://blog.csdn.net/hallo8888/article/details/109670020?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522165685944316780357252428%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=165685944316780357252428&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-1-109670020-null-null.142^v30^control,185^v2^control&utm_term=LL%E5%BA%93+IIC&spm=1018.2226.3001.4187
  ADC
  https://blog.csdn.net/qq_34752070/article/details/105555558?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522165692341516782425184170%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=165692341516782425184170&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-2-105555558-null-null.142^v30^control,185^v2^control&utm_term=LL%E5%BA%93+ADC&spm=1018.2226.3001.4187
  https://blog.csdn.net/crazy_kismet/article/details/105550170
  https://blog.csdn.net/qq_35002379/article/details/105947794
  
  https://www.cnblogs.com/armfly/p/12180331.html#:~:text=ADC%E6%9C%89%E4%B8%A4%E7%A7%8D%E6%97%B6%E9%92%9F,ker_ck%EF%BC%89%E3%80%82
  https://blog.csdn.net/weixin_44584198/article/details/119453399?spm=1001.2101.3001.6661.1&utm_medium=distribute.pc_relevant_t0.none-task-blog-2%7Edefault%7ECTRLIST%7Edefault-1-119453399-blog-117019527.pc_relevant_multi_platform_whitelistv1_exp2&depth_1-utm_source=distribute.pc_relevant_t0.none-task-blog-2%7Edefault%7ECTRLIST%7Edefault-1-119453399-blog-117019527.pc_relevant_multi_platform_whitelistv1_exp2&utm_relevant_index=1
  
  TIM
  https://www.cnblogs.com/yhpbook/p/yhp_stm32_tim.html
  
  PI
  https://zhuanlan.zhihu.com/p/454914546
  
  RCC
  https://blog.csdn.net/failurepointer/article/details/44961349
  
  PI�Զ�����
  https://blog.csdn.net/richardgann/article/details/99704448
  https://zhuanlan.zhihu.com/p/454914546#:~:text=%E5%BD%93%E6%8B%BF%E5%88%B0%E4%B8%80%E4%B8%AA%E6%96%B0%E7%94%B5%E6%9C%BA%E6%97%B6%EF%BC%8C%E9%9C%80%E8%A6%81%E5%9C%A8%E6%B5%8B%E5%8A%9F%E6%9C%BA%E4%B8%8A%E5%AF%B9%E7%94%B5%E6%B5%81%E7%8E%AFPI%E5%8F%82%E6%95%B0%E8%BF%9B%E8%A1%8C%E8%B0%83%E8%AF%95%EF%BC%8C%E6%88%96%E8%B0%83%E5%A4%A7%EF%BC%8C%E6%88%96%E8%B0%83%E5%B0%8F%EF%BC%8C%E6%88%96%E9%98%B2%E6%AD%A2%E7%94%B5%E6%B5%81%E7%8E%AF%E5%93%8D%E5%BA%94%E5%A4%AA%E6%85%A2%EF%BC%8C%E6%88%96%E9%98%B2%E6%AD%A2%E7%94%B5%E6%B5%81%E7%8E%AF%E5%A4%AA%E6%95%8F%E6%84%9F%E9%80%A0%E6%88%90%E9%80%9F%E5%BA%A6%E6%B3%A2%E5%8A%A8%E5%92%8C%E7%A1%AC%E4%BB%B6%E8%BF%87%E6%B5%81%E3%80%82%20%E8%B0%83%E5%8F%82%E6%95%B0%E7%9A%84%E8%BF%87%E7%A8%8B%E5%BE%80%E5%BE%80%E5%B0%B1%E8%A2%AB%E6%80%BB%E7%BB%93%E4%B8%BA%E7%BB%8F%E9%AA%8C%E8%B0%83%E5%8F%82%EF%BC%8C%E6%AF%94%E5%A6%82%E8%AF%B4%E5%85%88%E8%B0%83%E8%8A%82%E5%8F%82%E6%95%B0P%EF%BC%8C%E7%AD%89%E9%9D%99%E5%B7%AE%E6%AF%94%E8%BE%83%E5%B0%8F%E6%97%B6%EF%BC%8C%E5%86%8D%E9%80%82%E5%BD%93%E5%A2%9E%E5%8A%A0%E5%8F%82%E6%95%B0I%E3%80%82,%E8%BF%99%E7%A7%8D%E7%BB%8F%E9%AA%8C%E8%B0%83%E5%8F%82%E6%98%AF%E4%B8%8D%E6%98%AF%E5%8F%AF%E4%BB%A5%E9%81%BF%E5%85%8D%E5%91%A2%EF%BC%9F%20%E8%83%BD%E4%B8%8D%E8%83%BD%E8%AE%BE%E8%AE%A1%E4%B8%80%E5%A5%97PI%E5%8F%82%E6%95%B0%E8%87%AA%E9%80%82%E5%BA%94%E4%B8%8D%E5%90%8C%E7%9A%84%E7%94%B5%E6%9C%BA%EF%BC%8C%E5%AE%9E%E7%8E%B0PI%E5%8F%82%E6%95%B0%E8%87%AA%E5%8A%A8%E6%95%B4%E5%AE%9A%E5%91%A2%EF%BC%9F%20%E7%8E%B0%E5%9C%A8%E5%BE%88%E5%A4%9A%E8%8A%AF%E7%89%87%E5%8E%82%E5%AE%B6%E9%83%BD%E6%8F%90%E4%BE%9B%E4%BA%86PI%E5%8F%82%E6%95%B0%E8%87%AA%E5%8A%A8%E6%95%B4%E5%AE%9A%E7%9A%84%E6%96%B9%E6%A1%88%EF%BC%8C%E6%8B%BF%E4%BA%86%E4%B8%80%E4%B8%AA%E6%96%B0%E7%94%B5%E6%9C%BA%E4%B8%8D%E9%9C%80%E8%A6%81%E5%86%8D%E5%81%9A%E8%BF%87%E5%A4%9A%E7%9A%84%E6%89%8B%E5%8A%A8%E8%B0%83%E8%AF%95%E5%B0%B1%E5%8F%AF%E4%BB%A5%E8%AE%A9%E7%94%B5%E6%9C%BA%E8%BF%90%E8%A1%8C%E5%88%B0%E9%A2%9D%E5%AE%9A%E5%8A%9F%E7%8E%87%E3%80%82
  